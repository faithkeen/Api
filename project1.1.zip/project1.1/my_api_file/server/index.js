const express = require('express');
const { ethers } = require('ethers'); // Ensure ethers is correctly imported
require('dotenv').config(); // Load .env variables

const app = express();
const PORT = process.env.PORT || 3000;

// Use Infura project ID from the .env file
const INFURA_PROJECT_ID = process.env.INFURA_PROJECT_ID;

if (!INFURA_PROJECT_ID) {
    console.error('Infura Project ID is missing. Please check your .env file.');
    process.exit(1);
}
console.log(`Using Infura Project ID: ${INFURA_PROJECT_ID}`);

const provider = new ethers.providers.JsonRpcProvider(`https://mainnet.infura.io/v3/${INFURA_PROJECT_ID}`);

const contractAddress = '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48';
const contractABI = [
    {
        "constant": true,
        "inputs": [],
        "name": "name",
        "outputs": [
            { "name": "", "type": "string" }
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "symbol",
        "outputs": [
            { "name": "", "type": "string" }
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "decimals",
        "outputs": [
            { "name": "", "type": "uint8" }
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [],
        "name": "totalSupply",
        "outputs": [
            { "name": "", "type": "uint256" }
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    },
    {
        "constant": true,
        "inputs": [{ "name": "_owner", "type": "address" }],
        "name": "balanceOf",  // Corrected here
        "outputs": [
            { "name": "balance", "type": "uint256" }
        ],
        "payable": false,
        "stateMutability": "view",
        "type": "function"
    }
];

const contract = new ethers.Contract(contractAddress, contractABI, provider);

app.get('/FaithApiTest', async (req, res) => {
    try {
        const name = await contract.name();  // Fetch contract name
        const symbol = await contract.symbol();  // Fetch contract symbol
        const totalSupply = await contract.totalSupply();  // Fetch total supply

        res.json({
            success: true,
            data: {
                name,
                symbol,
                totalSupply: ethers.utils.formatUnits(totalSupply, 6)  // Assuming 6 decimal places for USDC
            }
        });
    } catch (error) {
        console.error(error); // Log the error for debugging
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
